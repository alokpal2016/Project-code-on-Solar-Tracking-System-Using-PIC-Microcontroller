/*Software delay function*/
void ms_delay(unsigned int itime)
{
	unsigned int i,j;
	for(i=0;i<itime;i++)
	{
		for(j=0;j<1275;j++);
	}
}