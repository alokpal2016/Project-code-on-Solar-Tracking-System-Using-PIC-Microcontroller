/*header file for solar panel*/
#include<htc.h>
#define SW0	RC4
#define SW1 RC5
extern void init_ports();
extern void read_initial_time();
extern unsigned int update_time();
extern void update_current_time();
extern unsigned int initial_rot(unsigned char hw,unsigned char mw,unsigned char sw);
extern unsigned int min_to_deg(unsigned int z);
extern unsigned int cal_deg(unsigned int deg1);
extern unsigned int cal_count(unsigned int deg1);
