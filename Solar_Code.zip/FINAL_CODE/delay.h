/*header file for software delay */
extern void ms_delay(unsigned int);