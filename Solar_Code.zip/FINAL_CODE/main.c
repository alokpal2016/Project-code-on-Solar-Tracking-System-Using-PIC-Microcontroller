/*main program code for solar tracking sytem*/
//header files which is included 
#include<stdio.h>
#include "lcd.h"
#include "delay.h"
#include"rtc.h"
#include"solar.h"
#include"eeprom.h"
#include"stepper.h"
#include"adc.h"
#include"serial.h"
#include"kbd.h"
__CONFIG(BORDIS & WDTDIS & LVPDIS & HS & PWRTEN & DEBUGDIS ); // congigure words to disable all these parametrs
// function to convert and display ADC values 
void ConvertAndDisplay1(unsigned int val,unsigned int digit,unsigned char digit2);
unsigned char buf1[20]={0};
unsigned int voltage,current,temp;
unsigned int power;
//functionl to initialize the port 
void init1_ports()
{
	ADCON1=0X06; // A/D control register 1, configures as digital input output port pins AN1 & AN2
 	TRISE=0X00;  // TO make port E as output port 
	TRISD=0X00;  // To make the port D as output port 
	TRISA=0X07;  // to make the corresponding port pins as input 
}
// data types 
unsigned char sw=0,mw=0,hw=0;
unsigned int result_pulses=0;
unsigned char start =0,mincount=0;

void main()
{ 
   //data types for adc results 
	unsigned char mod=0;
	unsigned int adcresult=0;
	unsigned int adcresult1=0;
	unsigned int adc=0;
	float cur=0,pow=0;
	init_ports();	// function call to initialize the ports 
	init1_ports();	//for adc	
    adc_init(0x00);
    serial_init();  //function call to initialize the ports for serial
	init_lcd();		//function call to initialize the LCD 
	write(0x80,0);	//write command to clear the lcd 
	lcd_puts("Solar Tracker"); // lcd command to message display on LCD 
	ms_delay(100); 			   // software delay call for 100 mili seconds 
	write(0x01,0);			   // command to clear the lcd 
	timer1_init();			   //timer1 initialized function
	eeprom_init(); 			   //eeprom memory initialized function
    ms_delay(200);				// software delay call for 200 mili seconds
    serial_string("solar data");//character string to display on PC by serialcommunication 
	serial_tx('\n'); 			// for a new line 
    serial_tx('\r');
	write(0x01,0); //to clear 
	read_initial_time();		// function call to read the initial time from eeprom 
	write(0x80,0);     			//write command to the lcd 

// to display the RTC on lcd
	ConvertAndDisplay1(hh,2,0);
	write(':',1);
	ConvertAndDisplay1(mm,2,0);
	write(':',1);
	ConvertAndDisplay1(ss,2,0);
	ms_delay(200);
	update_current_time();
	TMR1ON=1; 		//enable the timer1 
	PORTC=0X30;		// port c pins as output  

    while(1)
	{		
		write_eeprom(addressss, ss);
		write_eeprom(addressmm, mm);
		write_eeprom(addresshh, hh);
		s = read_eeprom(addressss);
		m = read_eeprom(addressmm);
		h = read_eeprom(addresshh);
		write(0x80,0);
		ConvertAndDisplay1(h,2,0);
		write(':',1);
		ConvertAndDisplay1(m,2,0);
		write(':',1);
		ConvertAndDisplay1(s,2,0);
        if(mm_count==1)
		{
				write(0x01,0);
				//To Display TEMPERATURE 
				write(0x80,0);
				write('T',1); 			//temperature notation 
				write(0x81,0);
				ConvertAndDisplay1(temp,4,4);
				write(223,1);
				write('C',1);			//symbol of temperature 
		/*		sprintf(buf1,"%d",temp);  // to print the temperature value from buf1 register
				lcd_puts(buf1);	serial_string(buf1); */  		// to write on the lcd
    	   		serial_tx(223);	serial_tx('C');	serial_tx('\t');  		// transmit data to serial communication
	
				//To Display VOLTAGE
				write(0x88,0);
			    write('V',1); 		//symbol of voltage
				write(0x89,0);	ConvertAndDisplay1(voltage,3,3);lcd_puts("mV"); //to display 
			/*	sprintf(buf1,"%d",voltage); // to print the value of voltage from buf1 register
			  	lcd_puts(buf1);   // to write on the lcd
				serial_string(buf1);*/
				serial_string("mV");serial_tx('\t');		
			
				//To Display CURRENT
 				write(0xc0,0);
				write('I',1); 	// symbol of current 
				cur=(float)current/1000;
				write(0xc2,0);//	ConvertAndDisplay1(current,3,3);lcd_puts("mA");
				sprintf(buf1,"%d",current);// to print the value of current from buf1 register
				lcd_puts(buf1);  //to write on lcd 
          		serial_string(buf1);lcd_puts("mA");
				serial_string("mA");serial_tx('\t');
				
				//To Display POWER
  			    write(0xC7,0);
				write('P',1);
				pow=cur*cur;
				power=pow*50;
				write(0xC9,0);
				ConvertAndDisplay1(power,1,1);
				write('W',1);
		/*		sprintf(buf1,"%d",power);// to print the value of power from buf1 register
				lcd_puts(buf1); // to write on lcd 
				serial_string(buf1);*/
				serial_tx('W');
				serial_tx('\t');
		 		ms_delay(250);		
				mm_count=0;
				write(0x01,0);
				serial_tx('\n');
    			serial_tx('\r');
		}
      
		if(!SW0)
		{
			hw=hh;
			mw=mm;
			sw=ss;
			result_pulses=initial_rot(hw,mw,sw);
			if(hw>=12)
			{
				clockwise(result_pulses);
			}
			else
			{
				anticlockwise(result_pulses);
			}
			PORTC=0X30;
			start=1;
			hw=mw=sw=0;	
			result_pulses=0;
		}
		if(!SW1)
		{
			hw=hh;
			mw=mm;
			sw=ss;
			result_pulses=initial_rot(hw,mw,sw);
			if(hw>=12)
			{
				anticlockwise(result_pulses);
			}
			else
			{
				clockwise(result_pulses);
			}
			PORTC=0X30;
			hw=mw=sw=0;
			result_pulses=0;
		}
		if(perminute&&start)
		{
			perminute=0;
			clockwise1(1);
			mincount++;
			if(mincount==5)
			{
				mincount=0;
				clockwise1(1);	
			}
		}
	switch(adc)
		{
			case 0:
    				 adc_init(0x00);
					 adcresult=process_adc();
					 adcresult1=adcresult*5;
            		 temp=adcresult1;
          			 adc++;
	       			 break;

			case 1: 
					 adc_init(0x08);
				 	 adcresult=process_adc();
					 adcresult1=adcresult*5;
					 voltage=adcresult1;                       
			    	 adc++;
	      			 break;

			case 2:	 
					adc_init(0x10);
					adcresult=process_adc();
					adcresult1=adcresult*5;
			    	current=adcresult1;      
          			adc++;

			case 3: 
				//	power=current*current;
				//	power=power*50;
                	adc++;
	       			break;
      		default:
      				adc=0;

		}

   }
	serial_tx('\n');
    serial_tx('\r');
}

void ConvertAndDisplay1(unsigned int val,unsigned int digit,unsigned char digit2)
{
	unsigned int temp;
 	unsigned char a[5];
   	temp=val;
	a[4]=temp%10;
  	temp=temp/10;
  	a[3]=temp%10;
  	temp=temp/10;
  	a[2]=temp%10;
  	temp=temp/10; 
  	a[1]=temp%10;
  	temp=temp/10;
   	a[0]=temp;
	int i;

	switch(digit)
	{
		case 1:
				write(a[4]+0x30,1);
				break;
		case 2:
				write(a[3]+0x30,1);
 				write(a[4]+0x30,1);
				break;
		case 3:
				write(a[1]+0x30,1);
				write(a[2]+0x30,1);
  				write(a[3]+0x30,1);
 				write(a[4]+0x30,1);
				break;
		case 4:
    			write(a[2]+0x30,1);
				write(a[3]+0x30,1);write('.',1);
 				write(a[4]+0x30,1);
				break;

		default:
				digit=0;
	}

	switch(digit2)
	{
		case 1: serial_tx(a[4]+0x30);
				break;

		case 2: serial_tx(a[3]+0x30);
 				serial_tx(a[4]+0x30);
				break;

		case 3:	serial_tx(a[1]+0x30);
				serial_tx(a[2]+0x30);
  				serial_tx(a[3]+0x30);
 				serial_tx(a[4]+0x30);
				break;

		case 4: serial_tx(a[2]+0x30);
  				serial_tx(a[3]+0x30);		serial_tx('.');
       			serial_tx(a[4]+0x30);
				break;

		default:digit2=0;
	}
	
}


