/*header file for matrix keypad(4x4)*/
#include<htc.h>
#define keypad PORTB
#define CHKCOL(val,pos) (val & 1<<pos)
#define CHKROW(val,pos) (val & 0x10<<pos)
unsigned int getrpm=0;
unsigned char buf[4] = {0};
unsigned char kp;
unsigned int num=100;
const unsigned int limit=360;
extern void init_key();
extern unsigned char get_key();

