/*header file for eeprom memory*/
#include<htc.h>
#define _XTAL_FREQ 4000000	
unsigned char value = 0x50;
unsigned char addressss=0x30;
unsigned char addressmm=0x31;
unsigned char addresshh=0x32;
extern void eeprom_init();
extern void write_eeprom(unsigned char adr, unsigned char d);
extern unsigned char read_eeprom(unsigned char adr);