/*program code foe stepper motor rotation*/
#include"stepper.h"
#include "delay.h"

// function for clockwise rotation
 void clockwise1(unsigned char count)
{ 			//series sequence 55,44,66,22,aa,88,99,11   
	unsigned char a=0,b=1,c=2,d=3,e=4,f=5,g=6,h=7,cnt=0;

	do
	{
		switch(varm)
		{	
			case 0:
                	stepper = 0x05;
               		ms_delay(20);
					++cnt;varm++;
					break;

			case 1:
					stepper = 0x04;
               		ms_delay(20);
					++cnt;varm++;
					break;

			case 2:
					stepper = 0x06;
               		ms_delay(20);
					++cnt;varm++;
					break;

			case 3:
					stepper = 0x02;
               		ms_delay(20);
					++cnt;varm++;
					break;

			case 4:
					stepper = 0x0a;
               		ms_delay(20);
					++cnt;varm++;
					break;

			case 5:
					stepper = 0x08;
              	 	ms_delay(20);
					++cnt;varm++;
					break;

			case 6:
					stepper = 0x09;
              	 	ms_delay(20);
					++cnt;varm++;
					break;

			case 7:
					stepper = 0x01;
              		ms_delay(20);
					++cnt;varm++;
					break;

			default:
					break;
               }
	}while(cnt<count);
       if(varm>7){varm=0;}
}
//function for anticlockwise rotation 
void anticlockwise1(unsigned char count)
{ 			  
			//series sequence 11,99,88,aa,22,66,44,55
unsigned char a=0,b=1,c=2,d=3,e=4,f=5,g=6,h=7,cnt=0;

	do
	{
		switch(varm1)
		{	
			case 0:
                	stepper = 0x01;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 1:
					stepper = 0x09;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 2:
					stepper = 0x08;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 3:
					stepper = 0x0a;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 4:
					stepper = 0x02;
              	 	ms_delay(20);
					++cnt;varm1++;
					break;

			case 5:
					stepper = 0x06;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 6:
					stepper = 0x04;
               		ms_delay(20);
					++cnt;varm1++;
					break;

			case 7:
					stepper = 0x05;
              		ms_delay(20);
					++cnt;varm1++;
					break;

			default:
					break;
               }
	}while(cnt<count);
     if(varm1>7){varm1=0;}
}

void anticlockwise(unsigned char count )
{
unsigned char a=0,b=1,c=2,d=3,cnt=0;	
	do
	{	
		if(a<=count-1)
               {
                stepper = 0x09;
             ms_delay(10);
                a=a+4;
                cnt=cnt+1;
			if(cnt==count)
			{
				goto label;
			}
               }
           
            if(b<=count-1)
               {
                stepper = 0x0a;
              ms_delay(10);
                b=b+4;
                cnt=cnt+1;
			if(cnt==count)
			{
				goto label;
			}
               }
            
            if(c<=count-1)
               {
                stepper = 0x06;
              ms_delay(10);
                c=c+4;
                cnt=cnt+1;
			if(cnt==count)
			{
				goto label;
			}
               }
            
            if(d<=count-1)
               {
                stepper = 0x05;
               ms_delay(10);
                d=d+4;
                cnt=cnt+1;
			if(cnt==count)
			{
				goto label;
			}
                }
		}while(cnt<=count);
                if(cnt==count)
                {
					label:cnt=0;a=0,b=1,c=2,d=3;

				}
}

void clockwise(unsigned char count )
{
unsigned char a=0,b=1,c=2,d=3,cnt=0;	
	do
	{	
		if(a<=count-1)
        	{
               	stepper = 0x05;
            	ms_delay(10);
               	a=a+4;
               	cnt=cnt+1;
			if(cnt==count)
			{
				goto label;
			}
             }
           
            if(b<=count-1)
               {
                stepper = 0x06;
             	ms_delay(10);
                b=b+4;
                cnt=cnt+1;

				if(cnt==count)
				{
					goto label;
				}
               }
            
            if(c<=count-1)
               {
                	stepper = 0x0a;
             		ms_delay(10);
                	c=c+4;
                	cnt=cnt+1;
				if(cnt==count)
				{
					goto label;
				}
               }
            
            if(d<=count-1)
               {
                	stepper = 0x09;
              		ms_delay(10);
              		d=d+4;
                	cnt=cnt+1;
				if(cnt==count)
				{
					goto label;
				}
                }
		}while(cnt<=count);
                if(cnt==count)
                {
					label:cnt=0;a=0,b=1,c=2,d=3;

				}
}



