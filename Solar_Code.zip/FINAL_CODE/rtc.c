/*A programe code for RTC*/

#include "delay.h"
#include"lcd.h"
#include"rtc.h"

void interrupt timer0()
{
	if(TMR1IF && TMR1IE)
	{
		TMR1IF=0;        //timer1 interrupt flag cleared  
		if(++(kcount)==999)
		{
			kcount=0;
			++ss; 			//second increment 
			if((ss)==60)
			{	
				++mm;
				ss = 0;    // seconds set to zero 
				perminute=1;
				mm_count++;  // minutes increment 
				if((mm)==60)
				{ 
					++hh;ss=0; // hour increment 
					mm = 0;   //minutes set to zero
					if((hh)==24)
					{
						hh = 0;mm=0;ss=0;
					}
				}
			}
		}
		TMR1H=0XFC;
		TMR1L=0X17;	
	}
}
void timer1_init() //function to timer1 initialization 
{
	T1CON=0X04; //set the timer1 control register 
	TMR1ON=0;   //to Stop Timer1
	TMR1H=0XFC; //timer1 higher byte 
	TMR1L=0X17; //timer1 lower byte 
	TMR1IF=0; //timer1 interrupt  flag
	GIE=1;   //global intrrupt enable set 
	PEIE=1; //peripheral interrupt 
	TMR1IE=1; //timer1 interrupt enable 
}

