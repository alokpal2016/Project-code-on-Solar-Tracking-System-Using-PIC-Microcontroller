/*program code for the matrix keypad(4x4)*/
//header files which is included  
#include "kbd.h"
#include "delay.h"
#include "lcd.h"
#include"rtc.h"
#include"eeprom.h"
// character array datatype  
unsigned char key_data[4][4]= {'0','1','2','3',	'4','5','6','7','8','9','A','B','C','D','N','Y'};
unsigned char row,col;
// function to initialize the key 
void init_key()
{
	TRISB= 0x0f;   //for reading coloums of keypad
	keypad =0x0f;   
	ms_delay(20);  // software delay call for 20miliseconds
		   
do
	{
	col=keypad;
	col&=0x0f;
	}
while(col==0x0f);			  
    TRISB=0xf0;		//to read the rows	  
	keypad=0xf0;    
	row=keypad;
	row&=0xf0; 
	ms_delay(50); // software delay call for 50miliseconds 
}		
// function to get the key 		
unsigned char get_key()
{	
	unsigned char i,key=0;		 
	for(i=0;i<4;i++)
		{
			if(!CHKCOL(col,i)) // to check the coulmn key
			{
				col=i;
				while(1)
				{
					if(!CHKROW(row,key)) // to check the row key  
					{	
						row=key;
						return(key_data[row][col]); // return key data wheather row or column
					} key++;                       //increment the next key  
				}	
			}
		}
		return(1); // to return the key value
}
