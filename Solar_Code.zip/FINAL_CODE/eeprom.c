/*programe code for EEPROM to store the data*/
#include "eeprom.h"
// function to initialization eeprom 
void eeprom_init()
{
	EEPGD = 0;
}
// function to write in the eeprom memory
void write_eeprom(unsigned char adr, unsigned char d)
{
   EEADR = adr;
   EEDATA = d;
   WREN = 1;  					// write enable 
   EECON2 = 0x55; 				// protection sequence
   EECON2 = 0xaa;
   WR = 1;  					// begin programming sequnce
   __delay_ms(20);              // to call the delay
   WREN = 0;  					// disable write enable
}
// function to read the data from eeprom
unsigned char read_eeprom(unsigned char adr)
{
   EEADR=adr;
   RD=1; // set the read bit
   return(EEDATA);
}