/*lcd header file*/
#include<htc.h>
//macro defined for lcd pins 
#define	rs RE0
#define	rw RE1
#define en RE2
extern void write(unsigned char,unsigned char);
extern void init_lcd();
extern void lcd_puts(const char * );



