/*program code for solar panel rotation*/
#include"rtc.h"
#include<stdio.h>
#include"solar.h"
#include"eeprom.h"
#include"kbd.h"
#include"lcd.h"
#include"adc.h"
#include"serial.h"
#include"delay.h"

unsigned char buf3[20] = {0};
unsigned char buf1[20] = {0};

void init_ports()
{
	ADCON1=0X06;
 	TRISE=0X00;
	TRISD=0X00;
    TRISC=0x00;
	TRISC=0X30;	
}

void read_initial_time()
{
	ss=read_eeprom(addressss);
	mm=read_eeprom(addressmm);
	hh=read_eeprom(addresshh);
 	if(ss==255 || mm==255 || hh==255)
	{
		ss=0;mm=0;hh=0;
	}
}

void update_current_time()
{
	write(0x80,0);
	lcd_puts("press Y/N");
 	write(0x8b,0);
 	init_key();
    kp= get_key();
	if(kp==1)
	{
		lcd_puts("NO KEY PRESSED");
	}
	write(kp,1);
	ms_delay(100);
	write(0x01,0);

	switch(kp)
	{
		case 'Y':hh=update_time();
		         mm=update_time();
				 ss=update_time();
			 	 break;

		case 'N':
				break;

		default:
				break;
	}
}

unsigned int update_time()
{
	unsigned int getrpm=0;
	unsigned int num=10;
	unsigned char i,flag=1;
	write(0x80,0);
	for(i=0;i<2;i++)
   	{ 
    	init_key();  
    	kp= get_key();
   	 	buf3[i]=kp;
		if(kp==1)
		{
			lcd_puts("NO KEY PRESSED");
		} 
		write(kp,1);
 		getrpm +=(buf3[i]-0x30)*num;
    	num=num/10;
   	} 
	return getrpm;
}

unsigned int initial_rot(unsigned char hw,unsigned char mw,unsigned char sw)
{
	unsigned int deg=0,pulses=0,degstep=0;
	unsigned int x,y,z=0;
	if(hw>=12)
	{
		x=hw-12;
		y=mw-0;
		x=60*x;
		z=x+y;
	}
	else
	{
		x=12-hw;
		y=0-mw;
		if(y<0)
		{
			x=x-1;
			y=60+y;	
		}
		x=60*x;
		z=x+y;
	}
	deg=min_to_deg(z);
	degstep=cal_deg(deg);
	pulses=cal_count(degstep);
	sprintf((char*)buf1,"%d %d %d %u",z,deg,degstep,pulses);
    write(0xc0,0);
    lcd_puts(buf1);
	ms_delay(250);	
	write(0x01,0);
	pulses=pulses/2;
	return pulses;
/*	anticlockwise(pulses);*/
}

unsigned int min_to_deg(unsigned int z)
{
	float result1;unsigned int result;
	result1=0.25*z;
	if((result1-(unsigned int)result1)>=0.5)
	{
		result=(unsigned int)result1+1;
	}
	else
	{
		result=(unsigned int)result1;
	}

	return result;
}

unsigned int cal_deg(unsigned int deg1)
{
	unsigned int result=0;
	unsigned char degc=223;
	float result1=0;
	result1=deg1*4.6;
	if((result1-(unsigned int)result1)>=0.5)
	{
		result=(unsigned int)result1+1;
	}
	else
	{
		result=(unsigned int)result1;
	}
	
	return result;
}

unsigned int cal_count(unsigned int deg1)
{
	float result;
	unsigned int result1=0;
	float temp;
	temp=(float)400/360;//*(unsigned long)deg1;
	result=temp*deg1;
	if((result-(unsigned int)result)>=0.5)
	{
		result1=(unsigned int)result+1;
	}
	else
	{
		result1=(unsigned int)result;
	}

	return result1;	
}