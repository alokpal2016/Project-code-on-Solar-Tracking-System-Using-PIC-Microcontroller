/*header file for stepper motor rotation*/
#include<htc.h>
#define stepper PORTC
unsigned char varm=0,varm1=0;
extern void anticlockwise1(unsigned char count );
extern void anticlockwise(unsigned char count);
extern void clockwise(unsigned char count );
extern void clockwise1(unsigned char count);