/*program code for serial communication*/
#include"serial.h"
void serial_init()
{

	SPBRG=25;          //hex value selected from table
    TXSTA= 0x26;	   //B'00100010';//settings for the transmitter
    RCSTA= 0x90;	   //B'10010000';//setting for receiver    
}

void serial_tx(unsigned char ch)
{
   TXREG=ch;
   while(!TXIF);
   TXIF=0;
   TRMT=0;
}

unsigned char serial_rx()
{
	unsigned char ch=0;
    while(!RCIF)
    continue;
    ch = RCREG;
    return ch;
}

void serial_string(const char *s)
{
	while(*s)
	{
		serial_tx(*s++);
	}
}
