/*A program code for the LCD */
#include<htc.h>
#include "lcd.h"
#include "delay.h"
#define _XTAL_FREQ 4000000

void write(unsigned char pos,unsigned char c)	//routine for writing commands and data on lcd
{
	PORTD=((pos>>4) & (0x0f)); // to put the value on the pins
	rs = c;	//rs for command or characters
	rw = 0;
	en = 1; //strobe the enable pin
	__delay_ms(10);
	en = 0;
	PORTD=(pos & 0x0f);
	rs = c;	//rs for command or characters
	rw = 0;
	en = 1; //strobe the enable pin
	__delay_ms(10);
	en = 0;
}

void init_lcd()
{
// lcd commands
	write(0x02,0);   
  	write(0x28,0);   //
  	write(0x0E,0);   //
  	write(0x06,0);   //  
  	write(0x80,0);   // 
  	write(0x01,0);	 //command to clear the LCD
}

//function to write a character string on the LCD 

void lcd_puts(const char * s)
{
	while(*s)
		write(*s++,1);
}

