/*header file for RTC */
#include<htc.h>
//structure for rtc 
struct rtc
{
	unsigned char s,m,h;
	unsigned int count1;
};
struct rtc p;
struct rtc *a=&p;
//macro defined for second, minute,hour 
#define ss a->s
#define mm a->m
#define hh a->h
#define kcount a->count1
unsigned char s,m,h=0;
unsigned char perminute=0;
unsigned char mm_count=0;
extern void timer1_init();
