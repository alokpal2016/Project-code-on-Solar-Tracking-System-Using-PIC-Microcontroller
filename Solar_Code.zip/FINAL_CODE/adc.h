/*header file for ADC*/
#include<htc.h>
extern void adc_init(unsigned char channel);
extern unsigned int process_adc();