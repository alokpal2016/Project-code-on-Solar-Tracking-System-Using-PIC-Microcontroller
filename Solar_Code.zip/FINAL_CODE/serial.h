/*header file for serial communication*/
#include <pic.h>

#define _XTAL_FREQ 4000000 // macro defined for crystal frequency

extern void serial_init();
extern void serial_tx(unsigned char ch);
extern unsigned char serial_rx();
extern void serial_string(const char *s);