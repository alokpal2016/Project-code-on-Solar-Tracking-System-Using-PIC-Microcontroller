/*program code for ADC conversion*/
#include"adc.h"
#define _XTAL_FREQ 4000000

void adc_init(unsigned char channel)
{
	ADCON1=0XC2;
	ADCON0=channel;	ADON=1;
}
unsigned int process_adc()
{
	unsigned int check=0,sum=0,average=0;
	unsigned char i=0;i=0;
	while(i<=30)
	{
		ADGO=1; // when it converts value is 0 and when it complets the value is 1.
		while(ADGO);
		check=(ADRESH<<8) + ADRESL; //10 bit adc result 
		sum=sum+check;              
		i++;check=0;ADRESH=0;ADRESL=0;
		__delay_us(500);
	}
	average=sum/30;   // To find the average value 
	i=0;
	return average;   // for return the average value 
}
   



 
